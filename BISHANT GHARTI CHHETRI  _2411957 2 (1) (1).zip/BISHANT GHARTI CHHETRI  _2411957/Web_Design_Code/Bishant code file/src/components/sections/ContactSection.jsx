
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Send, Mail, Phone, MapPin } from 'lucide-react';

const ContactInfoItem = ({ icon: Icon, text, href }) => (
  <motion.div 
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.5 }}
    className="flex items-center space-x-3 mb-4"
  >
    <Icon className="h-6 w-6 text-primary flex-shrink-0" />
    {href ? (
      <a href={href} className="text-muted-foreground hover:text-primary transition-colors">{text}</a>
    ) : (
      <span className="text-muted-foreground">{text}</span>
    )}
  </motion.div>
);

const ContactSection = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Basic form data logging, replace with actual submission logic
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());
    console.log("Form Data:", data);

    toast({
      title: "Message Sent! 🚀",
      description: "Thanks for reaching out, Bishant will get back to you soon!",
      variant: "default", 
    });
    e.target.reset();
  };

  return (
    <section id="contact" className="section-padding">
      <div className="max-w-5xl mx-auto">
        <h2 className="section-title">Get In Touch</h2>
        <p className="section-subtitle">
          Have a project idea, a question, or just want to say hi? Feel free to reach out. I'm always open to discussing new opportunities and collaborations.
        </p>
        <div className="grid md:grid-cols-2 gap-12 items-start">
          <motion.div 
            initial={{ opacity: 0, y:50 }}
            whileInView={{ opacity: 1, y:0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-semibold text-foreground mb-6">Contact Information</h3>
            <ContactInfoItem icon={Mail} text="contact@bishantgc.com" href="mailto:contact@bishantgc.com" />
            <ContactInfoItem icon={Phone} text="+977-98XXXXXXXX" href="tel:+9779800000000" />
            <ContactInfoItem icon={MapPin} text="Kathmandu, Nepal" />
            <p className="text-muted-foreground mt-6">
              I'm currently available for freelance projects and full-time opportunities. Let's build something amazing together!
            </p>
          </motion.div>

          <motion.form
            initial={{ opacity: 0, y:50 }}
            whileInView={{ opacity: 1, y:0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            onSubmit={handleSubmit}
            className="glassmorphic-card p-8 space-y-6"
          >
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1">Full Name</label>
              <Input type="text" name="name" id="name" placeholder="Your Name" required />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-1">Email Address</label>
              <Input type="email" name="email" id="email" placeholder="your.email@example.com" required />
            </div>
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-foreground mb-1">Subject</label>
              <Input type="text" name="subject" id="subject" placeholder="Subject of your message" required />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1">Message</label>
              <Textarea name="message" id="message" rows={5} placeholder="Your detailed message..." required />
            </div>
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              Send Message <Send className="ml-2 h-4 w-4" />
            </Button>
          </motion.form>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
