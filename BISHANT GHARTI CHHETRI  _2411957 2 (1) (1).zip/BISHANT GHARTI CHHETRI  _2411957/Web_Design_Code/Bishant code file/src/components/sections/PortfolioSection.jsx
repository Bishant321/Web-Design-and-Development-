
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github } from 'lucide-react';

const projects = [
  {
    title: "E-commerce Platform X",
    description: "A full-featured e-commerce site with React, Node.js, and Stripe integration. Modern UI, secure payments, and admin dashboard.",
    imageUrl: "e-commerce-project",
    tags: ["React", "Node.js", "Stripe", "MongoDB"],
    liveUrl: "#",
    repoUrl: "#",
  },
  {
    title: "Social Media App 'Connect'",
    description: "A social networking platform built with Next.js and Supabase. Real-time chat, post feeds, and user profiles.",
    imageUrl: "social-media-app",
    tags: ["Next.js", "Supabase", "TailwindCSS", "Real-time"],
    liveUrl: "#",
    repoUrl: "#",
  },
  {
    title: "AI Powered Task Manager",
    description: "An intelligent task management tool using OpenAI API for task suggestions and prioritization. Built with Vue.js and Firebase.",
    imageUrl: "ai-task-manager",
    tags: ["Vue.js", "Firebase", "OpenAI", "Productivity"],
    liveUrl: "#",
    repoUrl: "#",
  },
  {
    title: "Interactive Data Visualization",
    description: "A D3.js based project for visualizing complex datasets. Customizable charts and interactive filters.",
    imageUrl: "data-visualization-project",
    tags: ["D3.js", "JavaScript", "Data Analysis"],
    liveUrl: "#",
    repoUrl: "#",
  }
];

const PortfolioCard = ({ project, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="glassmorphic-card overflow-hidden group hover-lift"
    >
      <div className="relative h-56 w-full overflow-hidden">
        <img  
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            alt={project.title}
         src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
      </div>
      <div className="p-6">
        <h3 className="text-2xl font-semibold text-foreground mb-2">{project.title}</h3>
        <p className="text-muted-foreground text-sm mb-4 h-20 overflow-y-auto custom-scrollbar">{project.description}</p>
        <div className="mb-4">
          {project.tags.map(tag => (
            <span key={tag} className="inline-block bg-primary/20 text-primary text-xs font-semibold mr-2 mb-2 px-2.5 py-0.5 rounded-full">
              {tag}
            </span>
          ))}
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" size="sm" asChild className="border-primary text-primary hover:bg-primary/10">
            <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
              Live Demo <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button variant="ghost" size="sm" asChild className="text-muted-foreground hover:text-primary hover:bg-primary/10">
            <a href={project.repoUrl} target="_blank" rel="noopener noreferrer">
              <Github className="mr-2 h-4 w-4" /> Source Code
            </a>
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const PortfolioSection = () => {
  return (
    <section id="portfolio" className="section-padding">
      <div className="max-w-7xl mx-auto">
        <h2 className="section-title">My Portfolio</h2>
        <p className="section-subtitle">
          A selection of projects that showcase my skills and passion for web development. Each project represents a unique challenge and learning opportunity.
        </p>
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <PortfolioCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PortfolioSection;
