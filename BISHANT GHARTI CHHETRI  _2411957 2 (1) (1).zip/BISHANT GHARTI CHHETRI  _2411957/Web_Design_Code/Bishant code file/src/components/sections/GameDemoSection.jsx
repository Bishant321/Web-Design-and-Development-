
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import Phaser from 'phaser';
import { Button } from '@/components/ui/button';
import { PlayCircle, Square } from 'lucide-react';

let gameInstance = null;

const GameScene = new Phaser.Class({
  Extends: Phaser.Scene,
  initialize: function GameScene() {
    Phaser.Scene.call(this, { key: 'gameScene' });
    this.player = null;
    this.stars = null;
    this.bombs = null;
    this.platforms = null;
    this.cursors = null;
    this.score = 0;
    this.scoreText = null;
    this.gameOver = false;
  },

  preload: function () {
    this.load.image('sky', 'https://labs.phaser.io/assets/skies/space3.png');
    this.load.image('ground', 'https://labs.phaser.io/assets/sprites/platform.png');
    this.load.image('star', 'https://labs.phaser.io/assets/sprites/star.png');
    this.load.image('bomb', 'https://labs.phaser.io/assets/sprites/bomb.png');
    this.load.spritesheet('dude', 'https://labs.phaser.io/assets/sprites/dude.png', {
      frameWidth: 32,
      frameHeight: 48,
    });
  },

  create: function () {
    this.gameOver = false;
    this.score = 0;

    this.add.image(400, 300, 'sky');
    this.platforms = this.physics.add.staticGroup();
    this.platforms.create(400, 568, 'ground').setScale(2).refreshBody();
    this.platforms.create(600, 400, 'ground');
    this.platforms.create(50, 250, 'ground');
    this.platforms.create(750, 220, 'ground');

    this.player = this.physics.add.sprite(100, 450, 'dude');
    this.player.setBounce(0.2);
    this.player.setCollideWorldBounds(true);

    this.anims.create({
      key: 'left',
      frames: this.anims.generateFrameNumbers('dude', { start: 0, end: 3 }),
      frameRate: 10,
      repeat: -1,
    });
    this.anims.create({
      key: 'turn',
      frames: [{ key: 'dude', frame: 4 }],
      frameRate: 20,
    });
    this.anims.create({
      key: 'right',
      frames: this.anims.generateFrameNumbers('dude', { start: 5, end: 8 }),
      frameRate: 10,
      repeat: -1,
    });

    this.cursors = this.input.keyboard.createCursorKeys();

    this.stars = this.physics.add.group({
      key: 'star',
      repeat: 11,
      setXY: { x: 12, y: 0, stepX: 70 },
    });
    this.stars.children.iterate(function (child) {
      child.setBounceY(Phaser.Math.FloatBetween(0.4, 0.8));
    });

    this.bombs = this.physics.add.group();
    this.scoreText = this.add.text(16, 16, 'Score: 0', {
      fontSize: '32px',
      fill: '#FFF',
      fontFamily: 'Arial, sans-serif',
      stroke: '#000',
      strokeThickness: 4,
    });

    this.physics.add.collider(this.player, this.platforms);
    this.physics.add.collider(this.stars, this.platforms);
    this.physics.add.collider(this.bombs, this.platforms);
    this.physics.add.overlap(this.player, this.stars, this.collectStar, null, this);
    this.physics.add.collider(this.player, this.bombs, this.hitBomb, null, this);
  },

  update: function () {
    if (this.gameOver) return;

    if (this.cursors.left.isDown) {
      this.player.setVelocityX(-160);
      this.player.anims.play('left', true);
    } else if (this.cursors.right.isDown) {
      this.player.setVelocityX(160);
      this.player.anims.play('right', true);
    } else {
      this.player.setVelocityX(0);
      this.player.anims.play('turn');
    }
    if (this.cursors.up.isDown && this.player.body.touching.down) {
      this.player.setVelocityY(-330);
    }
  },

  collectStar: function (player, star) {
    star.disableBody(true, true);
    this.score += 10;
    this.scoreText.setText('Score: ' + this.score);

    if (this.stars.countActive(true) === 0) {
      this.stars.children.iterate(function (child) {
        child.enableBody(true, child.x, 0, true, true);
      });
      const x = player.x < 400 ? Phaser.Math.Between(400, 800) : Phaser.Math.Between(0, 400);
      const bomb = this.bombs.create(x, 16, 'bomb');
      bomb.setBounce(1);
      bomb.setCollideWorldBounds(true);
      bomb.setVelocity(Phaser.Math.Between(-200, 200), 20);
    }
  },

  hitBomb: function (player, bomb) {
    this.physics.pause();
    player.setTint(0xff0000);
    player.anims.play('turn');
    this.gameOver = true;
    this.scoreText.setText('Game Over! Score: ' + this.score + '\nClick button to restart.');
  }
});


const GameDemoSection = () => {
  const gameContainerRef = useRef(null);
  const [isGameRunning, setIsGameRunning] = useState(false);

  const startGame = () => {
    if (gameInstance) {
      gameInstance.destroy(true);
    }
    
    const config = {
      type: Phaser.AUTO,
      width: 800,
      height: 600,
      parent: gameContainerRef.current,
      physics: {
        default: 'arcade',
        arcade: {
          gravity: { y: 300 },
          debug: false,
        },
      },
      scene: [GameScene],
      backgroundColor: '#000020'
    };
    gameInstance = new Phaser.Game(config);
    setIsGameRunning(true);
  };
  
  const stopGame = () => {
    if (gameInstance) {
      gameInstance.destroy(true);
      gameInstance = null;
    }
    setIsGameRunning(false);
  }

  useEffect(() => {
    return () => {
      if (gameInstance) {
        gameInstance.destroy(true);
        gameInstance = null;
      }
    };
  }, []);

  return (
    <section id="game" className="section-padding bg-card/30">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="section-title">Interactive Game Demo</h2>
        <p className="section-subtitle">
          Experience a mini-game built with Phaser.js! Collect stars, avoid bombs, and try to get the highest score.
        </p>
        
        <div className="mb-8 flex justify-center space-x-4">
          {!isGameRunning ? (
             <Button onClick={startGame} size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
               <PlayCircle className="mr-2 h-5 w-5" /> Start Game
             </Button>
          ) : (
            <Button onClick={stopGame} variant="destructive" size="lg">
              <Square className="mr-2 h-5 w-5" /> Stop Game
            </Button>
          )}
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: isGameRunning ? 1 : 0.5, scale: isGameRunning ? 1 : 0.9 }}
          transition={{ duration: 0.5 }}
          id="phaser-game-container"
          ref={gameContainerRef}
          className="w-full max-w-[800px] h-[600px] mx-auto bg-background border-2 border-primary rounded-lg shadow-2xl overflow-hidden relative"
        >
          {!isGameRunning && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 backdrop-blur-sm">
              <PlayCircle className="w-24 h-24 text-primary mb-4 opacity-70" />
              <p className="text-2xl text-foreground">Click "Start Game" to play!</p>
            </div>
          )}
        </motion.div>
      </div>
    </section>
  );
};

export default GameDemoSection;
