import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Layers, Cpu, Database, Users, Palette, Code } from 'lucide-react';
import * as THREE from 'three';

const SkillCard = ({ icon: Icon, title, description, delay }) => (
  <motion.div
    initial={{ opacity: 0, y: 50 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    className="glassmorphic-card p-6 flex flex-col items-center text-center hover-lift"
  >
    <Icon className="h-12 w-12 text-primary mb-4" />
    <h3 className="text-xl font-semibold text-foreground mb-2">{title}</h3>
    <p className="text-muted-foreground text-sm">{description}</p>
  </motion.div>
);

const AboutSection = () => {
  const skillsCubeRef = useRef(null);

  useEffect(() => {
    if (!skillsCubeRef.current) return;

    const currentRef = skillsCubeRef.current;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, currentRef.clientWidth / currentRef.clientHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    
    renderer.setSize(currentRef.clientWidth, currentRef.clientHeight);
    currentRef.appendChild(renderer.domElement);

    const geometry = new THREE.BoxGeometry(2.5, 2.5, 2.5);
    const materials = [
        new THREE.MeshStandardMaterial({ color: 0x007bff, roughness: 0.5, metalness: 0.2 }),
        new THREE.MeshStandardMaterial({ color: 0x6c757d, roughness: 0.5, metalness: 0.2 }),
        new THREE.MeshStandardMaterial({ color: 0x28a745, roughness: 0.5, metalness: 0.2 }),
        new THREE.MeshStandardMaterial({ color: 0xffc107, roughness: 0.5, metalness: 0.2 }),
        new THREE.MeshStandardMaterial({ color: 0xdc3545, roughness: 0.5, metalness: 0.2 }),
        new THREE.MeshStandardMaterial({ color: 0x6f42c1, roughness: 0.5, metalness: 0.2 })
    ];
    const cube = new THREE.Mesh(geometry, materials);
    scene.add(cube);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(5, 10, 7.5);
    scene.add(directionalLight);

    camera.position.z = 5;

    let animationFrameId;
    const animate = function () {
        animationFrameId = requestAnimationFrame(animate);
        cube.rotation.x += 0.005;
        cube.rotation.y += 0.005;
        renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (currentRef) {
        camera.aspect = currentRef.clientWidth / currentRef.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(currentRef.clientWidth, currentRef.clientHeight);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (currentRef && renderer.domElement) {
        currentRef.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  const skills = [
    { icon: Layers, title: "Frontend Wizardry", description: "React, Next.js, Vue.js, TailwindCSS, Framer Motion. Crafting beautiful and responsive UIs.", delay: 0.1 },
    { icon: Cpu, title: "Backend Prowess", description: "Node.js, Express, Python, Django. Building robust and scalable server-side applications.", delay: 0.2 },
    { icon: Database, title: "Database Management", description: "MongoDB, PostgreSQL, MySQL, Supabase. Designing efficient data structures.", delay: 0.3 },
    { icon: Users, title: "Full-Stack Solutions", description: "End-to-end development, bridging the gap between frontend and backend seamlessly.", delay: 0.4 },
    { icon: Palette, title: "UI/UX Enthusiasm", description: "Focus on user-centric design, creating intuitive and enjoyable experiences.", delay: 0.5 },
    { icon: Code, title: "DevOps & Tools", description: "Git, Docker, Vite, Webpack. Streamlining development and deployment pipelines.", delay: 0.6 }
  ];

  return (
    <section id="about" className="section-padding bg-card/30">
      <div className="max-w-7xl mx-auto">
        <h2 className="section-title">About Me</h2>
        <p className="section-subtitle">
          A passionate Full Stack Developer based in Nepal, with a knack for building innovative web solutions. I thrive on challenges and continuously explore new technologies to enhance my craft.
        </p>
        
        <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <motion.div 
            initial={{ opacity: 0, x: -100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            id="skills-cube-container" 
            ref={skillsCubeRef} 
            className="h-80 md:h-96 w-full rounded-lg overflow-hidden glassmorphic-card p-2"
          >
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 100 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h3 className="text-3xl font-semibold text-foreground mb-4">My Journey & Philosophy</h3>
            <p className="text-muted-foreground mb-4">
              From my first "Hello World" to complex full-stack applications, my journey in web development has been fueled by curiosity and a desire to create impactful digital products. I believe in clean code, continuous learning, and collaborative problem-solving.
            </p>
            <p className="text-muted-foreground">
              When I'm not coding, you can find me exploring the latest tech trends, contributing to open-source projects, or enjoying a good cup of coffee.
            </p>
          </motion.div>
        </div>

        <h3 className="text-3xl font-semibold text-foreground mb-8 text-center gradient-text">Core Skills</h3>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map(skill => <SkillCard key={skill.title} {...skill} />)}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;