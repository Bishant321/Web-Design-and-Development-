import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowDown } from 'lucide-react';

const HeroSection = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let t = 0;
    let isMounted = true;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const plasmaShader = (x, y, time) => {
      const v1 = Math.sin(x * 0.02 + time * 0.5);
      const v2 = Math.sin(y * 0.02 + time * 0.5);
      const v3 = Math.sin((x + y) * 0.02 + time * 0.5);
      const v4 = Math.sin(Math.sqrt(x*x + y*y) * 0.015 + time * 0.3);
      const combined = v1 + v2 + v3 + v4;
      return combined;
    };

    const render = () => {
      if (!isMounted || canvas.width === 0 || canvas.height === 0) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      t += 0.01;
      const imageData = ctx.createImageData(canvas.width, canvas.height);
      const data = imageData.data;

      for (let x = 0; x < canvas.width; x++) {
        for (let y = 0; y < canvas.height; y++) {
          const value = plasmaShader(x, y, t);
          const R = Math.floor(128 + 127 * Math.sin(value * Math.PI));
          const G = Math.floor(128 + 127 * Math.sin(value * Math.PI + 2 * Math.PI / 3));
          const B = Math.floor(128 + 127 * Math.sin(value * Math.PI + 4 * Math.PI / 3));
          
          const index = (y * canvas.width + x) * 4;
          data[index] = R;
          data[index + 1] = G;
          data[index + 2] = B;
          data[index + 3] = 255;
        }
      }
      ctx.putImageData(imageData, 0, 0);
      animationFrameId = requestAnimationFrame(render);
    };
    
    resizeCanvas(); 
    window.addEventListener('resize', resizeCanvas);
    render();

    return () => {
      isMounted = false;
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center text-center overflow-hidden">
      <canvas ref={canvasRef} id="shader-canvas"></canvas>
      <div className="relative z-10 p-6">
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
          className="text-5xl sm:text-6xl md:text-7xl font-extrabold mb-6"
        >
          <span className="block text-foreground">Hi, I'm Bishant</span>
          <span className="gradient-text block">Creative Web Developer</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
          className="max-w-2xl mx-auto text-lg sm:text-xl text-muted-foreground mb-10"
        >
          I craft immersive and engaging web experiences with modern technologies, transforming ideas into digital realities.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6, ease: "easeOut" }}
          className="space-x-4"
        >
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 text-lg">
            View My Work
            <ArrowDown className="ml-2 h-5 w-5 animate-bounce" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;