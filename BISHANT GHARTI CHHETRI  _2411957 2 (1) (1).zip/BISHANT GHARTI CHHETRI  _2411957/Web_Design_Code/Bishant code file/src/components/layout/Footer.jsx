
import React from 'react';
import { Github, Linkedin, Twitter, Mail } from 'lucide-react';

const SocialLink = ({ href, icon: Icon, label }) => (
  <a
    href={href}
    target="_blank"
    rel="noopener noreferrer"
    aria-label={label}
    className="text-muted-foreground hover:text-primary transition-colors duration-300"
  >
    <Icon className="h-6 w-6" />
  </a>
);

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-card/50 border-t border-border section-padding">
      <div className="max-w-7xl mx-auto text-center">
        <div className="flex justify-center space-x-6 mb-6">
          <SocialLink href="https://github.com/bishantgc" icon={Github} label="GitHub" />
          <SocialLink href="https://linkedin.com/in/bishantghartichhetri" icon={Linkedin} label="LinkedIn" />
          <SocialLink href="https://twitter.com/bishantgc" icon={Twitter} label="Twitter" />
          <SocialLink href="mailto:contact@bishantgc.com" icon={Mail} label="Email" />
        </div>
        <p className="text-muted-foreground text-sm">
          Designed & Built by Bishant Gharti Chhetri
        </p>
        <p className="text-muted-foreground text-sm">
          &copy; {currentYear} All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
