
import React from 'react';
import HeroSection from '@/components/sections/HeroSection';
import AboutSection from '@/components/sections/AboutSection';
import PortfolioSection from '@/components/sections/PortfolioSection';
import GameDemoSection from '@/components/sections/GameDemoSection';
import ContactSection from '@/components/sections/ContactSection';

const HomePage = () => {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <PortfolioSection />
      <GameDemoSection />
      <ContactSection />
    </>
  );
};

export default HomePage;
